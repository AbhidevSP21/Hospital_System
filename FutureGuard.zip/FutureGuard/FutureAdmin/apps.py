from django.apps import AppConfig


class FutureadminConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'FutureAdmin'
